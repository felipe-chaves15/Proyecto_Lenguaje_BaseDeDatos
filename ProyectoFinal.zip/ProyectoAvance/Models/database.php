<?php
$oracle = oci_connect('LENGDB_ADM', '1234', 'localhost/XE');
var_dump($oracle);