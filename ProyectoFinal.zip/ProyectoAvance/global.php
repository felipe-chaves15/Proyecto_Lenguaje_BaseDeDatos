<?php
    define("ROOT", "/PROYECTOAVANCE");
    define("PATH", dirname(__DIR__) . "/PROYECTOAVANCE");
    define("CONTROLLERS_PATH", PATH . "/Controllers");
    define("MODELS_PATH", PATH . "/Models");
    define("STYLES_PATH", PATH . "/Styles");
    define("VIEWS_PATH", PATH . "/Views");
?>